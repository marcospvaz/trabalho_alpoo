package factory;

import java.sql.Connection; 
// conex�o
import java.sql.DriverManager; 
// driver de conex�o SQL to Java 
import java.sql.SQLException;  
// tratamento de exce��es

public class ConnectionFactory {

     public Connection getConnection() {
		 try {
			return DriverManager.getConnection("jdbc:mysql://localhost/projetojava","root","605077@Bd");
		 }         
		 catch(SQLException excecao) {
			throw new RuntimeException(excecao);
		 }
     }
}
